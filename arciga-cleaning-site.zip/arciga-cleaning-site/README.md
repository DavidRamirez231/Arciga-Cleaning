# Arciga Cleaning Website

Professional residential cleaning service website for Long Beach, CA.

## Quick Start

```bash
# Install dependencies
npm install

# Run locally
npm run dev

# Build for production
npm run build
```

## Deployment to Vercel (Recommended - Free)

### Option 1: GitHub + Vercel (Easiest)

1. **Push to GitHub**
   - Create a new repository on GitHub
   - Push this code to the repository

2. **Connect to Vercel**
   - Go to [vercel.com](https://vercel.com) and sign up with GitHub
   - Click "Add New Project"
   - Import your GitHub repository
   - Click "Deploy" - that's it!

3. **Custom Domain (Optional)**
   - In Vercel dashboard, go to your project > Settings > Domains
   - Add your domain (e.g., arcigacleaning.com)
   - Update DNS records as instructed

### Option 2: Vercel CLI

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

## Form Setup (Formspree)

The contact form uses Formspree for submissions:

1. Go to [formspree.io](https://formspree.io) and create a free account
2. Create a new form
3. Copy your form ID (looks like: `xyzabcde`)
4. In `src/App.jsx`, replace `YOUR_FORM_ID` with your actual form ID:

```javascript
const response = await fetch('https://formspree.io/f/YOUR_FORM_ID', {
```

## Customization Checklist

Before going live, update these:

- [ ] Phone number in footer (currently placeholder)
- [ ] Email address in footer
- [ ] Formspree form ID
- [ ] Add real testimonials
- [ ] Update pricing if needed
- [ ] Add Google Analytics (optional)

## Tech Stack

- React 18
- Vite
- Tailwind CSS
- Lucide React Icons

## File Structure

```
arciga-cleaning-site/
├── public/
│   └── favicon.svg
├── src/
│   ├── App.jsx        # Main website component
│   ├── main.jsx       # Entry point
│   └── index.css      # Styles + Tailwind
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
└── postcss.config.js
```
